﻿export { default } from "../../dispatch/page";
