﻿// app/actions/dispatchActions.ts
//
// Simple client-safe helper used by /admin/livetripss/page.tsx
// It fetches the latest active booking + driver locations from Supabase
// and returns an object that page.tsx + DriverListPanel expect.

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  // This will show up in the browser console if env vars are missing
  // but will not break the build.
  console.warn(
    "[dispatchActions] Missing NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY"
  );
}

// Common headers for Supabase REST
const supabaseHeaders: HeadersInit = {
  apikey: SUPABASE_ANON_KEY,
  Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
};

type DriverRow = {
  driver_id: string;
  lat: number | null;
  lng: number | null;
  status: string;
  town: string | null;
  updated_at: string;
};

type DriverTownGroup = {
  town: string;
  drivers: DriverRow[];
};

type DriverStats = {
  total: number;
  online: number;
  onTrip: number;
  offline: number;
  towns: DriverTownGroup[];
};

type LiveTripResult = {
  booking: any | null;
  driverStats: DriverStats;
};

/**
 * Fetch the most recent active booking (assigned / on_trip) together
 * with aggregated driver stats & per-town lists.
 *
 * This shape matches what /admin/livetripss/page.tsx + DriverListPanel
 * are expecting: { booking, driverStats }.
 */
export async function getActiveBookingWithDriverLocations(): Promise<LiveTripResult> {
  // ---- 1) Active booking (from dispatch_rides_view) ----
  let booking: any | null = null;

  try {
    const bookingRes = await fetch(
      `${SUPABASE_URL}/rest/v1/dispatch_rides_view` +
        `?status=in.(assigned,on_trip)&order=created_at.desc&limit=1`,
      {
        headers: supabaseHeaders,
        cache: "no-store",
      }
    );

    if (bookingRes.ok) {
      const bookingRows = (await bookingRes.json()) as any[];
      booking = bookingRows[0] ?? null;
    } else {
      console.warn(
        "[dispatchActions] Failed to load dispatch_rides_view:",
        bookingRes.status,
        await safeText(bookingRes)
      );
    }
  } catch (err) {
    console.error("[dispatchActions] Error fetching active booking:", err);
  }

  // ---- 2) Driver locations & stats ----
  let driverRows: DriverRow[] = [];

  try {
    const driverRes = await fetch(
      `${SUPABASE_URL}/rest/v1/driver_locations` +
        `?select=driver_id,lat,lng,status,town,updated_at`,
      {
        headers: supabaseHeaders,
        cache: "no-store",
      }
    );

    if (driverRes.ok) {
      driverRows = (await driverRes.json()) as DriverRow[];
    } else {
      console.warn(
        "[dispatchActions] Failed to load driver_locations:",
        driverRes.status,
        await safeText(driverRes)
      );
    }
  } catch (err) {
    console.error("[dispatchActions] Error fetching driver_locations:", err);
  }

  const driverStats = buildDriverStats(driverRows);

  return {
    booking,
    driverStats,
  };
}

/** Build totals + per-town groups from raw driver_locations rows */
function buildDriverStats(rows: DriverRow[]): DriverStats {
  const total = rows.length;
  const online = rows.filter((r) => r.status === "online").length;
  const onTrip = rows.filter((r) => r.status === "on_trip").length;
  const offline = total - online - onTrip;

  const grouped: Record<string, DriverRow[]> = {};

  for (const row of rows) {
    const town = ((row as any).town ?? (row as any).zone ?? "Other");
    if (!grouped[town]) grouped[town] = [];
    grouped[town].push(row);
  }

  const towns: DriverTownGroup[] = Object.entries(grouped).map(
    ([town, drivers]) => ({
      town,
      drivers: drivers.sort(
        (a, b) =>
          new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
      ),
    })
  );

  return {
    total,
    online,
    onTrip,
    offline,
    towns,
  };
}

// Small helper to avoid throwing when logging response bodies
async function safeText(res: Response): Promise<string> {
  try {
    return await res.text();
  } catch {
    return "";
  }
}







