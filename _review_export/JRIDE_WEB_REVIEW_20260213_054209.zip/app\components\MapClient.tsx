﻿"use client";
/** Temporary stub: keep imports happy, render nothing */
export default function MapClient() { return null; }
