﻿"use client";
export const dynamic = "force-static";

export default function PayoutsPage() {
  return (
    <main className="p-6 max-w-md mx-auto">
      <h1 className="text-xl font-semibold mb-3">Driver Payouts</h1>
      <p className="text-sm text-gray-600">Payout summary will appear here.</p>
    </main>
  );
}
