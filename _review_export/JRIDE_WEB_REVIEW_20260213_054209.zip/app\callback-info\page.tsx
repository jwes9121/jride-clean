"use client";
export const dynamic = "force-static";

export default function CallbackInfo() {
  return (
    <main className="p-6 max-w-md mx-auto">
      <h1 className="text-xl font-semibold mb-3">Signing you in…</h1>
      <p className="text-sm">If this takes more than a few seconds, please return to the sign-in page.</p>
    </main>
  );
}
