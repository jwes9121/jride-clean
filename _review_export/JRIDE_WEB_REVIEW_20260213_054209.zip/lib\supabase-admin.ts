﻿export { supabaseAdmin } from "./supabaseAdmin";
