"use client";

import React, { useEffect, useMemo, useState } from "react";

type Props = {
  // Accept both prop names (LiveTripsClient passes selectedTrip)
  trip?: any | null;
  selectedTrip?: any | null;

  // P6C: UI-only copy suggested fare into a draft field upstream
  onUseSuggestedFare?: (v: number) => void;
};

function asNum(v: any): number | null {
  if (v === null || v === undefined) return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function fmtMoney(v: any) {
  const n = asNum(v);
  if (n === null) return "--";
  return n.toFixed(2);
}

function fmtDate(v: any) {
  if (!v) return "--";
  try {
    const d = new Date(v);
    if (Number.isNaN(d.getTime())) return String(v);
    return d.toISOString().replace("T", " ").replace("Z", " UTC");
  } catch {
    return String(v);
  }
}

/**
 * Schema-aligned:
 * bookings has verified_fare, proposed_fare, total_errand_fare, and components:
 * base_fee, distance_fare, extra_stop_fee, waiting_fee
 */

function isTakeoutTrip(trip: any): boolean {
  if (!trip) return false;
  const tt = String(trip?.trip_type ?? trip?.tripType ?? "").trim().toLowerCase();
  if (tt === "takeout") return true;
  const code = String(trip?.booking_code ?? trip?.bookingCode ?? "").trim().toUpperCase();
  return code.startsWith("TAKEOUT-") || code.startsWith("TAKEOUT_") || code.startsWith("TAKEOUT");
}
function computeFareFromBooking(trip: any): number | null {
  // TAKEOUT fare fields (read-only display; do NOT assume schema)
  const direct = asNum(trip?.fare);
  if (direct !== null) return direct;
  const totalFare = asNum(trip?.total_fare);
  if (totalFare !== null) return totalFare;
  const totalAmt = asNum(trip?.total_amount);
  if (totalAmt !== null) return totalAmt;
  const amount = asNum(trip?.amount);
  if (amount !== null) return amount;
  const orderTotal = asNum(trip?.order_total);
  if (orderTotal !== null) return orderTotal;
  const subtotal = asNum(trip?.subtotal);
  if (subtotal !== null) return subtotal;
  const deliveryFee = asNum(trip?.delivery_fee);
  if (deliveryFee !== null) return deliveryFee;

  const verified = asNum(trip?.verified_fare);
  if (verified !== null) return verified;

  const proposed = asNum(trip?.proposed_fare);
  if (proposed !== null) return proposed;

  const errandTotal = asNum(trip?.total_errand_fare);
  if (errandTotal !== null) return errandTotal;

  const baseFee = asNum(trip?.base_fee) ?? 0;
  const distFare = asNum(trip?.distance_fare) ?? 0;
  const extraStop = asNum(trip?.extra_stop_fee) ?? 0;
  const waitingFee = asNum(trip?.waiting_fee) ?? 0;

  const sum = baseFee + distFare + extraStop + waitingFee;
  return sum > 0 ? sum : null;
}

type LedgerKind = "driver" | "vendor";

function getId(trip: any, kind: LedgerKind): string | null {
  if (!trip) return null;
  if (kind === "driver") {
    return (
      trip?.driver_id ??
      trip?.driverId ??
      trip?.assigned_driver_id ??
      trip?.assignedDriverId ??
      null
    );
  }
  return trip?.vendor_id ?? trip?.vendorId ?? null;
}

function pickNote(row: any): string {
  return (
    row?.reason ??
    row?.note ??
    row?.kind ??
    row?.type ??
    row?.description ??
    "--"
  );
}

function pickAmount(row: any): any {
  return row?.amount ?? row?.delta ?? row?.value ?? null;
}

function pickBalanceAfter(row: any): any {
  return row?.balance_after ?? row?.balanceAfter ?? row?.balance ?? null;
}

export default function TripWalletPanel(props: Props) {
  const trip = (props && (props as any).trip !== undefined) ? (props as any).trip : ((props as any).selectedTrip ?? null);
  const onUseSuggestedFare = (props as any)?.onUseSuggestedFare as ((v: number) => void) | undefined;
  const fare = useMemo(() => computeFareFromBooking(trip), [trip]);
  const isTakeout = useMemo(() => isTakeoutTrip(trip), [trip]);
  // TAKEOUT display-only estimate (based on your business rule: vendor earns 90%)
  const derivedFare = useMemo(() => {
    if (!isTakeout) return null;
    const vb = asNum(trip?.vendor_wallet_balance);
    if (vb === null) return null;
    if (vb <= 0) return null;
    // fare ÃƒÆ’Ã†'Ãƒâ€šÃ‚¢ÃƒÆ’Ã‚¢Ãƒ¢Ã¢â‚¬Å¡Ã‚¬Ãƒâ€šÃ‚°ÃƒÆ’Ã¢â‚¬¹Ãƒ¢Ã¢â€š¬Ã‚  vendorEarnings / 0.90
    return Math.round((vb / 0.90) * 100) / 100;
  }, [trip, isTakeout]);

  const derivedCompanyCut = useMemo(() => {
    if (!isTakeout) return null;
    if (derivedFare === null) return null;
    const vb = asNum(trip?.vendor_wallet_balance);
    if (vb === null) return null;
    const cut = derivedFare - vb; // ÃƒÆ’Ã†'Ãƒâ€šÃ‚¢ÃƒÆ’Ã‚¢Ãƒ¢Ã¢â‚¬Å¡Ã‚¬Ãƒâ€šÃ‚°ÃƒÆ’Ã¢â‚¬¹Ãƒ¢Ã¢â€š¬Ã‚  10%
    return Math.round(cut * 100) / 100;
  }, [trip, isTakeout, derivedFare]);

  
  const fareDisplay = useMemo(() => {
    // If we have a real fare, use it. Else for TAKEOUT, use derivedFare.
    if (fare !== null) return fare;
    if (isTakeout && derivedFare !== null) return derivedFare;
    return null;
  }, [fare, isTakeout, derivedFare]);

  


  // P6A: Suggested verified fare (UI-only; wired later)
  const suggestedFare = asNum(
    trip?.suggested_verified_fare ??
    trip?.suggested_fare ??
    trip?.fare_suggestion ??
    trip?.suggestedFare ??
    null
  );
const companyCut = useMemo(() => {
    const explicit = asNum(trip?.company_cut ?? trip?.platform_fee ?? trip?.commission ?? trip?.company_fee);
    if (explicit !== null) return explicit;
    // If no explicit field, for TAKEOUT show derived cut from vendor_wallet_balance (10% rule)
    if (isTakeout && derivedCompanyCut !== null) return derivedCompanyCut;
    return null;
  }, [trip, isTakeout, derivedCompanyCut]);
const driverPayout = useMemo(() => {
    const explicit = asNum(trip?.driver_payout ?? trip?.driver_fee ?? trip?.driver_earnings ?? trip?.driver_cut);
    if (explicit !== null) return explicit;
    return null;
  }, [trip]);
  // ===== JRIDE_P5B_PASSENGER_CHARGES_BLOCK (computed, read-only) =====
  // Passenger-facing fees (if present on trip row)
  const passengerPickupFee = useMemo(() => {
    return asNum(trip?.pickup_distance_fee ?? trip?.pickupDistanceFee ?? trip?.pickup_fee ?? null);
  }, [trip]);

  const passengerPlatformFee = useMemo(() => {
    // Keep separate from company_cut; passenger platform fee should be explicit (e.g., platform_service_fee)
    return asNum(trip?.platform_service_fee ?? trip?.platformServiceFee ?? trip?.platform_service ?? null);
  }, [trip]);

  const passengerBaseFare = useMemo(() => {
    const v = asNum(trip?.verified_fare);
    if (v !== null) return v;
    const p = asNum(trip?.proposed_fare);
    if (p !== null) return p;
    // fallback to fareDisplay (already computed above)
    return asNum(fareDisplay);
  }, [trip, fareDisplay]);

  const passengerTotalToPay = useMemo(() => {
    const explicit =
      asNum(trip?.total_to_pay ?? trip?.totalToPay ?? trip?.passenger_total ?? trip?.passengerTotal ?? null);
    if (explicit !== null) return explicit;

    if (passengerBaseFare === null) return null;
    const pu = passengerPickupFee ?? 0;
    const pf = passengerPlatformFee ?? 0;
    return Math.round((passengerBaseFare + pu + pf) * 100) / 100;
  }, [trip, passengerBaseFare, passengerPickupFee, passengerPlatformFee]);

  const showPassengerCharges = useMemo(() => {
    if (isTakeout) return false;
    const hasAny =
      asNum(trip?.verified_fare) !== null ||
      asNum(trip?.proposed_fare) !== null ||
      passengerPickupFee !== null ||
      passengerPlatformFee !== null ||
      asNum(trip?.total_to_pay ?? trip?.totalToPay ?? null) !== null;
    return !!hasAny;
  }, [trip, isTakeout, passengerPickupFee, passengerPlatformFee]);
  // ===== END JRIDE_P5B_PASSENGER_CHARGES_BLOCK =====


  // Wallet balances: show if API provides computed fields
  const driverWallet = useMemo(
    () => trip?.driver_wallet_balance ?? trip?.driver_wallet ?? trip?.driverWallet ?? null,
    [trip]
  );
  const vendorWallet = useMemo(
    () => trip?.vendor_wallet_balance ?? trip?.vendor_wallet ?? trip?.vendorWallet ?? null,
    [trip]
  );

  // ---- Ledger modal state ----
  const [open, setOpen] = useState(false);
  const [kind, setKind] = useState<LedgerKind>("driver");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [rows, setRows] = useState<any[]>([]);

  const driverId = useMemo(() => getId(trip, "driver"), [trip]);
  const vendorId = useMemo(() => getId(trip, "vendor"), [trip]);

  useEffect(() => {
    if (!open) return;

    const id = kind === "driver" ? driverId : vendorId;
    if (!id) {
      setErr(kind === "driver" ? "No driver_id on this trip." : "No vendor_id on this trip.");
      setRows([]);
      return;
    }

    let cancelled = false;

    async function run() {
      setLoading(true);
      setErr(null);
      setRows([]);

      try {
        const idStr = String(id);
        const qs = new URLSearchParams({ kind, id: idStr, limit: "20" });
        const res = await fetch(`/api/admin/wallet/transactions?${qs.toString()}`, {
          cache: "no-store",
        });

        const json = await res.json().catch(() => null);

        if (cancelled) return;

        if (!res.ok || !json?.ok) {
          const msg =
            json?.message ??
            json?.error ??
            json?.details ??
            `HTTP ${res.status}`;
          setErr(String(msg));
          setRows([]);
          return;
        }

        setRows(Array.isArray(json.rows) ? json.rows : []);
      } catch (e: any) {
        if (cancelled) return;
        setErr(String(e?.message || e));
        setRows([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    run();

    return () => {
      cancelled = true;
    };
  }, [open, kind, driverId, vendorId]);

  function openLedger(k: LedgerKind) {
  // JRIDE_PHASE7A_OPENLEDGER_GUARD
  // Prevent confusing modal when trip has no driver/vendor id (e.g., takeout-like bookings)
  if (k === "driver" && !driverId) {
    setErr("No driver_id on this trip.");
    return;
  }
  if (k === "vendor" && !vendorId) {
    setErr("No vendor_id on this trip.");
    return;
  }
    setKind(k);
    setOpen(true);
  }

  return (
    <>
      <div className="grid grid-cols-2 gap-2">
        <div className="rounded border bg-white p-2">
          <div className="text-slate-500">Fare</div>
          <div className="font-semibold">{fmtMoney(fareDisplay)}</div>
          <div className="mt-1 text-xs text-slate-500">
            Suggested verified fare: <span className="font-medium text-slate-700">{fmtMoney(suggestedFare)}</span>
            <button
              type="button"
              onClick={async () => {
                const n = asNum(suggestedFare);
                if (n === null) return;

                // UI-only: copy into upstream draft (preferred)
                if (onUseSuggestedFare) onUseSuggestedFare(n);

                // Bonus: clipboard copy (best-effort)
                try {
                  if (navigator && (navigator as any).clipboard && (navigator as any).clipboard.writeText) {
                    await (navigator as any).clipboard.writeText(String(n));
                  }
                } catch {}
              }}
              disabled={!(asNum(suggestedFare) !== null && (asNum(suggestedFare) as any) > 0)}
              className="ml-2 rounded border px-2 py-0.5 text-[11px] hover:bg-black/5 disabled:opacity-40 disabled:cursor-not-allowed"
              title="Copy suggested fare into Proposed Fare (draft)"
            >
              Use Suggested Fare
            </button>
          </div>
        </div>

        <div className="rounded border bg-white p-2">
          <div className="text-slate-500">Company cut</div>
          <div className="font-semibold">{fmtMoney(companyCut)}</div>
        </div>

        <div className="rounded border bg-white p-2">
          <div className="text-slate-500">Driver payout</div>
          <div className="font-semibold">{fmtMoney(driverPayout)}</div>
        </div>

        <div className="rounded border bg-white p-2">
          <div className="text-slate-500">Driver wallet</div>
          <div className="font-semibold">{fmtMoney(driverWallet)}</div>
          <button
            type="button"
            onClick={() => openLedger("driver")}
            disabled={!driverId}
            className="mt-1 text-xs underline text-slate-600 disabled:opacity-40"
            title={driverId ? "View driver wallet ledger (read-only)" : "No driver on this trip"}
          >
            View ledger
          </button>
        </div>

                {showPassengerCharges && (
          <div className="rounded border bg-white p-2 col-span-2">
            <div className="flex items-center justify-between">
              <div className="text-slate-500">Passenger charges (read-only)</div>
              <div className="text-[11px] text-slate-400">P5B</div>
            </div>

            <div className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
              <div className="flex items-center justify-between">
                <div className="text-slate-600">Fare (offer/verified)</div>
                <div className="font-semibold">{fmtMoney(passengerBaseFare)}</div>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-slate-600">Pickup Distance Fee</div>
                <div className={"font-semibold " + ((passengerPickupFee ?? 0) > 0 ? "text-amber-700" : "")}>
                  {fmtMoney(passengerPickupFee)}
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="text-slate-600">Platform Service Fee</div>
                <div className="font-semibold">{fmtMoney(passengerPlatformFee)}</div>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-slate-900 font-semibold">Total to Pay</div>
                <div className="text-slate-900 font-bold">{fmtMoney(passengerTotalToPay)}</div>
              </div>
            </div>

            <div className="mt-2 text-[11px] text-slate-500">
              This section mirrors passenger-facing line items when those fields are present on the booking.
            </div>
          </div>
        )}
<div className="rounded border bg-white p-2 col-span-2">
          <div className="text-slate-500">Vendor wallet</div>
          <div className="font-semibold">{fmtMoney(vendorWallet)}</div>
          <button
            type="button"
            onClick={() => openLedger("vendor")}
            disabled={!vendorId}
            className="mt-1 text-xs underline text-slate-600 disabled:opacity-40"
            title={vendorId ? "View vendor wallet ledger (read-only)" : "No vendor on this trip"}
          >
            View ledger
          </button>
        </div>
      </div>

      {open && (
        <div
          className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/40 p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-3xl rounded-lg bg-white shadow-lg">
            <div className="flex items-center justify-between border-b p-3">
              <div className="font-semibold">
                {kind === "driver" ? "Driver wallet ledger" : "Vendor wallet ledger"}{" "}
                <span className="text-xs font-normal text-slate-500">
                  (read-only)
                </span>
              </div>
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="rounded border px-2 py-1 text-sm"
              >
                Close
              </button>
            </div>

            <div className="p-3">
              <div className="mb-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setKind("driver")}
                  className={
                    "rounded px-2 py-1 text-sm border " +
                    (kind === "driver" ? "bg-slate-900 text-white" : "bg-white")
                  }
                >
                  Driver
                </button>
                <button
                  type="button"
                  onClick={() => setKind("vendor")}
                  className={
                    "rounded px-2 py-1 text-sm border " +
                    (kind === "vendor" ? "bg-slate-900 text-white" : "bg-white")
                  }
                >
                  Vendor
                </button>
                <div className="ml-auto text-xs text-slate-500">
                  ID: {kind === "driver" ? (driverId ?? "--") : (vendorId ?? "--")}
                </div>
              </div>

              {loading && (
                <div className="text-sm text-slate-600">Loading...</div>
              )}

              {!loading && err && (
                <div className="rounded border border-red-200 bg-red-50 p-2 text-sm text-red-700">
                  {err}
                </div>
              )}

              {!loading && !err && (
                <div className="overflow-auto rounded border">
                  <table className="min-w-full text-sm">
                    <thead className="bg-slate-50">
                      <tr className="text-left">
                        <th className="p-2">Created</th>
                        <th className="p-2">Amount</th>
                        <th className="p-2">Balance after</th>
                        <th className="p-2">Note</th>
                      </tr>
                    </thead>
                    <tbody>
                      {rows.length === 0 ? (
                        <tr>
                          <td className="p-2 text-slate-500" colSpan={4}>
                            No rows.
                          </td>
                        </tr>
                      ) : (
                        rows.map((r: any, idx: number) => (
                          <tr key={r?.id ?? idx} className="border-t">
                            <td className="p-2 whitespace-nowrap">{fmtDate(r?.created_at ?? r?.createdAt)}</td>
                            <td className="p-2 whitespace-nowrap">{fmtMoney(pickAmount(r))}</td>
                            <td className="p-2 whitespace-nowrap">{fmtMoney(pickBalanceAfter(r))}</td>
                            <td className="p-2">{pickNote(r)}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              )}

              <div className="mt-2 text-xs text-slate-500">
                This modal is read-only and does not change balances.
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}





