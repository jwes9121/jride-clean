-- Run these in Supabase SQL editor and paste results
select column_name, data_type
from information_schema.columns
where table_schema='public' and table_name in ('bookings','driver_locations','dispatch_actions')
order by table_name, ordinal_position;

select t.tgname, t.tgenabled
from pg_trigger t
join pg_class c on c.oid=t.tgrelid
join pg_namespace n on n.oid=c.relnamespace
where n.nspname='public' and c.relname='bookings' and not t.tgisinternal
order by t.tgname;

select routine_schema, routine_name, routine_type
from information_schema.routines
where routine_schema='public'
  and routine_name ilike '%assign%'
order by routine_name;