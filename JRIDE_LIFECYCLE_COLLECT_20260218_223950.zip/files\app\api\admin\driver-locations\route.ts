// app/api/admin/driver-locations/route.ts
// Admin view of driver_locations table in Supabase

import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";
export const fetchCache = "default-no-store";

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

function getSupabaseHeaders() {
  if (!supabaseUrl || !supabaseServiceKey) {
    throw new Error("Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY");
  }
  return {
    apikey: supabaseServiceKey,
    Authorization: `Bearer ${supabaseServiceKey}`,
    "Content-Type": "application/json",
  };
}

// GET /api/admin/driver-locations?status=online (status optional)
export async function GET(request: Request) {
  try {
    const headers = getSupabaseHeaders();
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");

    let url = `${supabaseUrl}/rest/v1/driver_locations?select=*`;
    if (status) {
      url += `&status=eq.${encodeURIComponent(status)}`;
    }

    const res = await fetch(url, {
      method: "GET",
      headers,
      cache: "no-store",
    });

    const data = await res.json();

    if (!res.ok) {
      console.error("Supabase driver_locations GET error:", data);
          // Normalize for Admin UI: treat "online" as "available"
          // (Does NOT change DB; only the API response used by LiveTrips.)
          try {
            // If the handler uses variables named "drivers" / "driver_locations", normalize them.
            // If not defined, this safely throws and is ignored.
            // @ts-ignore
            if (typeof drivers !== "undefined") {
              // @ts-ignore
              drivers = (drivers || []).map((r: any) => {
                const s = String((r as any)?.status || "").trim().toLowerCase();
                return s === "online" ? { ...r, status: "available" } : r;
              });
            }
            // @ts-ignore
            if (typeof driver_locations !== "undefined") {
              // @ts-ignore
              driver_locations = (driver_locations || []).map((r: any) => {
                const s = String((r as any)?.status || "").trim().toLowerCase();
                return s === "online" ? { ...r, status: "available" } : r;
              });
            }
          } catch { /* ignore */ }

      return NextResponse.json(
        {
          ok: false,
          error: "UPSTREAM_ERROR",
          message: "Failed to load driver_locations from Supabase",
          details: data,
        },
        { status: res.status }
      );
    }

    return NextResponse.json(
      {
        ok: true,
        rows: data,
      },
      { status: 200 }
    );
  } catch (err) {
    console.error("driver-locations unexpected error:", err);
    return NextResponse.json(
      {
        ok: false,
        error: "DRIVER_LOCATIONS_ERROR",
        message: "Unexpected error while fetching driver locations",
      },
      { status: 500 }
    );
  }
}

